CREATE DATABASE IF NOT EXISTS student_portal;
USE student_portal;
CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  roll_no VARCHAR(30) NOT NULL UNIQUE,
  email VARCHAR(120) NOT NULL,
  course VARCHAR(60) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- metadata of every uploaded file, linked to a student
CREATE TABLE student_files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  label VARCHAR(30) NOT NULL,          -- profile / id_proof / certificate
  file_path VARCHAR(255) NOT NULL,     -- stored (unique) file name
  file_type VARCHAR(100) NOT NULL,     -- MIME type
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash CHAR(64) NOT NULL
);
INSERT INTO users(username,password_hash) VALUES ('admin', SHA2('admin123',256));
