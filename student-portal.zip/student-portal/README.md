# Student Admission Portal (U21CS501 – Assignment II)

| Folder | Content |
|---|---|
| `db/schema.sql` | MySQL schema (students, student_files, users) |
| `q1-form/` | HTML5 + CSS3 + JS validated registration form |
| `q2-php/` | PHP CRUD + secure file upload + metadata in MySQL |
| `q3-servlet/` | Servlet + JDBC + JSP portal, session filter, file streaming |

## Run
1. Import `db/schema.sql` (XAMPP/phpMyAdmin). Login for Q3: `admin / admin123`.
2. Copy folder to `htdocs`, open `http://localhost/student-portal/q1-form/index.html` and `q2-php/index.php`.
3. Q3: Tomcat 9, add `mysql-connector-j`, `jstl-1.2.jar`, `javax.servlet-api` to `WEB-INF/lib`;
   compile `src/portal/*.java` into `WEB-INF/classes`; set `UPLOAD_DIR` in `web.xml`; open `/login.jsp`.

## Conclusion
The portal combines a validated front end, a PHP/MySQL admin panel with secure uploads (size, real MIME check, unique names),
and a Java servlet front end that streams files and restricts access using session filters. File metadata is linked to each student
via a foreign key, keeping data consistent when records change.
