<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:Arial;margin:16px}
.card{border:1px solid #ccc;border-radius:10px;padding:12px;margin:12px 0}
img{max-width:160px;border-radius:8px;margin-right:8px}
</style>
<h2>Welcome, ${sessionScope.user} | <a href="logout">Logout</a></h2>
<%-- loop over all students --%>
<c:forEach var="s" items="${students}">
  <div class="card">
    <h3>${s.name} (${s.rollNo})</h3>
    <p>${s.email} &middot; ${s.course}</p>
    <%-- conditional logic: files or none --%>
    <c:choose>
      <c:when test="${empty s.files}"><i>No files uploaded</i></c:when>
      <c:otherwise>
        <c:forEach var="f" items="${s.files}">
          <c:choose>
            <c:when test="${f.image}"><img src="file?id=${f.id}" alt="${f.label}"></c:when>
            <c:otherwise><a href="file?id=${f.id}" target="_blank">${f.label} (document)</a> </c:otherwise>
          </c:choose>
        </c:forEach>
      </c:otherwise>
    </c:choose>
  </div>
</c:forEach>
<c:if test="${empty students}"><p>No students found.</p></c:if>
