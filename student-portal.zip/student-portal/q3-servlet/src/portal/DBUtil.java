package portal;
import java.sql.*;
public class DBUtil {
  public static Connection get() throws Exception {
    Class.forName("com.mysql.cj.jdbc.Driver");
    return DriverManager.getConnection("jdbc:mysql://localhost:3306/student_portal", "root", "");
  }
}
