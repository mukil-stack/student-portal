package portal;
import java.io.*;
import java.nio.file.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

// Streams an image/document from the upload folder: <img src="file?id=5">
@WebServlet("/file")
public class FileServlet extends HttpServlet {
  protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
    String path = null, type = null;
    try (Connection c = DBUtil.get(); PreparedStatement ps = c.prepareStatement("SELECT file_path,file_type FROM student_files WHERE id=?")) {
      ps.setInt(1, Integer.parseInt(req.getParameter("id")));
      try (ResultSet rs = ps.executeQuery()) { if (rs.next()) { path = rs.getString(1); type = rs.getString(2); } }
    } catch (Exception e) { res.sendError(400); return; }
    if (path == null) { res.sendError(404); return; }
    Path base = Paths.get(getServletContext().getInitParameter("UPLOAD_DIR")).toAbsolutePath().normalize();
    Path file = base.resolve(path).normalize();
    if (!file.startsWith(base) || !Files.exists(file)) { res.sendError(404); return; }   // block path traversal
    res.setContentType(type);
    res.setContentLengthLong(Files.size(file));
    res.setHeader("Content-Disposition", "inline; filename=\"" + file.getFileName() + "\"");
    Files.copy(file, res.getOutputStream());
  }
}
