package portal;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;

// Session handling: only logged-in users reach these URLs
@WebFilter(urlPatterns = {"/students", "/file", "/students.jsp"})
public class AuthFilter implements Filter {
  public void doFilter(ServletRequest rq, ServletResponse rs, FilterChain ch) throws IOException, ServletException {
    HttpServletRequest req = (HttpServletRequest) rq;
    HttpSession ses = req.getSession(false);
    if (ses == null || ses.getAttribute("user") == null) {
      ((HttpServletResponse) rs).sendRedirect(req.getContextPath() + "/login.jsp");
      return;
    }
    ch.doFilter(rq, rs);
  }
}
