package portal;
import java.util.*;
public class Student {
  public static class FileInfo {
    private int id; private String label, type;
    public FileInfo(int id, String label, String type){ this.id=id; this.label=label; this.type=type; }
    public int getId(){return id;} public String getLabel(){return label;} public String getType(){return type;}
    public boolean isImage(){ return type != null && type.startsWith("image/"); }
  }
  private int id; private String name, rollNo, email, course;
  private List<FileInfo> files = new ArrayList<>();
  public Student(int id, String n, String r, String e, String c){ this.id=id; name=n; rollNo=r; email=e; course=c; }
  public int getId(){return id;} public String getName(){return name;} public String getRollNo(){return rollNo;}
  public String getEmail(){return email;} public String getCourse(){return course;} public List<FileInfo> getFiles(){return files;}
}
