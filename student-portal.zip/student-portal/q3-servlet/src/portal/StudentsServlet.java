package portal;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

// Fetches students + file metadata via JDBC, forwards to JSP
@WebServlet("/students")
public class StudentsServlet extends HttpServlet {
  protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    Map<Integer, Student> map = new LinkedHashMap<>();
    try (Connection c = DBUtil.get(); Statement st = c.createStatement()) {
      try (ResultSet rs = st.executeQuery("SELECT id,name,roll_no,email,course FROM students ORDER BY roll_no")) {
        while (rs.next())
          map.put(rs.getInt(1), new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
      }
      try (ResultSet rs = st.executeQuery("SELECT id,student_id,label,file_type FROM student_files")) {
        while (rs.next()) {
          Student s = map.get(rs.getInt(2));
          if (s != null) s.getFiles().add(new Student.FileInfo(rs.getInt(1), rs.getString(3), rs.getString(4)));
        }
      }
    } catch (Exception e) { throw new ServletException(e); }
    req.setAttribute("students", new ArrayList<>(map.values()));
    req.getRequestDispatcher("/students.jsp").forward(req, res);
  }
}
