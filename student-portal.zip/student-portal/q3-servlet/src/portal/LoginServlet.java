package portal;
import java.io.IOException;
import java.security.MessageDigest;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
  static String sha256(String s) throws Exception {
    StringBuilder sb = new StringBuilder();
    for (byte b : MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"))) sb.append(String.format("%02x", b));
    return sb.toString();
  }
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    try (Connection c = DBUtil.get();
         PreparedStatement ps = c.prepareStatement("SELECT id FROM users WHERE username=? AND password_hash=?")) {
      ps.setString(1, req.getParameter("username"));
      ps.setString(2, sha256(req.getParameter("password")));
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          req.getSession(true).setAttribute("user", req.getParameter("username"));
          res.sendRedirect("students");
          return;
        }
      }
    } catch (Exception e) { throw new RuntimeException(e); }
    res.sendRedirect("login.jsp?error=1");
  }
}
