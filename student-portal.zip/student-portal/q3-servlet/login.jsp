<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:Arial;max-width:320px;margin:60px auto}input{width:100%;padding:8px;margin:6px 0}</style>
<h2>Portal Login</h2>
<% if (request.getParameter("error") != null) { %><p style="color:#c00">Invalid credentials</p><% } %>
<form method="post" action="login">
  <input name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password" required>
  <button>Login</button>
</form>
