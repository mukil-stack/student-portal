// Client-side validation for the registration form
const $ = id => document.getElementById(id);
const rules = {
  name:  v => v.trim().length >= 3 ? "" : "Name must be at least 3 characters",
  roll:  v => /^[0-9]{2}[A-Za-z]{2,3}[0-9]{3}$/.test(v.trim()) ? "" : "Roll number format: 21CS101",
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "" : "Enter a valid email address",
  course:v => v ? "" : "Please select a course",
  // password strength: 8+ chars, upper, lower, digit, special
  pwd:   v => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}$/.test(v)
              ? "" : "Min 8 chars with upper, lower, digit and special character"
};
function check(id){
  const el = $(id), msg = rules[id](el.value);
  $(id + "Err").textContent = msg;
  el.classList.toggle("invalid", !!msg);
  el.classList.toggle("valid", !msg);
  return !msg;
}
function checkFile(){
  const f = $("file").files[0]; let msg = "";
  if (!f) msg = "Please choose a file";
  else if (!/\.(jpe?g|png|pdf)$/i.test(f.name)) msg = "Only JPG, PNG or PDF allowed";
  else if (f.size > 2 * 1024 * 1024) msg = "File must be under 2 MB";
  $("fileErr").textContent = msg;
  return !msg;
}
Object.keys(rules).forEach(id => $(id).addEventListener("input", () => check(id)));
$("file").addEventListener("change", checkFile);
$("regForm").addEventListener("submit", e => {
  const ok = Object.keys(rules).map(check).concat(checkFile()).every(Boolean);
  if (!ok) e.preventDefault();   // block submit if any field invalid
});
