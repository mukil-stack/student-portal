<?php /* shared form: $s = student row (or empty), $errors = array */ ?>
<style>body{font-family:Arial;max-width:520px;margin:20px auto;padding:0 12px}input,select{width:100%;padding:8px;margin:4px 0 12px}.err{color:#c00}</style>
<?php foreach ($errors as $er) echo '<p class="err">' . e($er) . '</p>'; ?>
<form method="post" enctype="multipart/form-data">
  Name <input name="name" required value="<?= e($s['name'] ?? '') ?>">
  Roll No <input name="roll_no" required value="<?= e($s['roll_no'] ?? '') ?>">
  Email <input type="email" name="email" required value="<?= e($s['email'] ?? '') ?>">
  Course <input name="course" required value="<?= e($s['course'] ?? '') ?>">
  Profile image <input type="file" name="profile" accept=".jpg,.jpeg,.png">
  ID proof <input type="file" name="id_proof" accept=".jpg,.jpeg,.png,.pdf">
  Certificate <input type="file" name="certificate" accept=".jpg,.jpeg,.png,.pdf">
  <button>Save</button> <a href="index.php">Back</a>
</form>
