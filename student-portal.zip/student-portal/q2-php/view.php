<?php require 'config.php';
$id = (int)($_GET['id'] ?? 0);
$q = $pdo->prepare('SELECT * FROM students WHERE id=?'); $q->execute([$id]); $s = $q->fetch();
if (!$s) { http_response_code(404); exit('Student not found'); }
$f = $pdo->prepare('SELECT * FROM student_files WHERE student_id=?'); $f->execute([$id]); $files = $f->fetchAll();
?>
<style>body{font-family:Arial;max-width:600px;margin:20px auto;padding:0 12px}img{max-width:200px;border-radius:8px}</style>
<h2><?= e($s['name']) ?></h2>
<p>Roll No: <?= e($s['roll_no']) ?><br>Email: <?= e($s['email']) ?><br>Course: <?= e($s['course']) ?></p>
<h3>Uploaded Files</h3>
<?php foreach ($files as $fl): $url = 'uploads/' . rawurlencode($fl['file_path']); ?>
  <div><b><?= e($fl['label']) ?></b> (<?= e($fl['file_type']) ?>, <?= e($fl['uploaded_at']) ?>)<br>
  <?php if (strpos($fl['file_type'], 'image/') === 0): ?><img src="<?= $url ?>" alt="">
  <?php else: ?><a href="<?= $url ?>" target="_blank">Open document</a><?php endif; ?></div><hr>
<?php endforeach; if (!$files) echo '<p>No files uploaded.</p>'; ?>
<a href="index.php">Back</a>
