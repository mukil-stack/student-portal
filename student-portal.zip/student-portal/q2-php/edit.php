<?php require 'config.php';
$id = (int)($_GET['id'] ?? 0); $errors = [];
$q = $pdo->prepare('SELECT * FROM students WHERE id=?'); $q->execute([$id]); $s = $q->fetch();
if (!$s) { http_response_code(404); exit('Student not found'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    $pdo->prepare('UPDATE students SET name=?,roll_no=?,email=?,course=? WHERE id=?')
        ->execute([trim($_POST['name']), trim($_POST['roll_no']), trim($_POST['email']), trim($_POST['course']), $id]);
    $errors = saveAllUploads($pdo, $id);
    if (!$errors) { header('Location: view.php?id=' . $id); exit; }
    $s = $_POST;
  } catch (PDOException $ex) { $errors[] = 'Roll number already exists or DB error'; }
}
echo '<h2>Edit Student</h2>'; include '_form.php';
