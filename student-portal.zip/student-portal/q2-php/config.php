<?php
// DB connection (PDO + prepared statements prevent SQL injection)
$pdo = new PDO('mysql:host=localhost;dbname=student_portal;charset=utf8mb4', 'root', '', [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);
const UPLOAD_DIR = __DIR__ . '/uploads/';
const MAX_SIZE   = 2 * 1024 * 1024;                       // 2 MB
const ALLOWED    = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','pdf'=>'application/pdf'];

function e($s){ return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

// Validates and stores one uploaded file, then saves metadata. Returns error string or ''.
function saveUpload(PDO $pdo, int $sid, string $field, string $label): string {
  if (empty($_FILES[$field]['name'])) return '';           // optional field
  $f = $_FILES[$field];
  if ($f['error'] !== UPLOAD_ERR_OK) return "$label: upload failed (code {$f['error']})";
  if ($f['size'] > MAX_SIZE) return "$label: file exceeds 2 MB";
  $ext  = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
  $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);   // real type, not client-supplied
  if (!isset(ALLOWED[$ext]) || ALLOWED[$ext] !== $mime) return "$label: only JPG, PNG, PDF allowed";
  $name = $sid . '_' . $label . '_' . uniqid() . '.' . $ext;     // unique name => never overwrites
  if (file_exists(UPLOAD_DIR . $name)) return "$label: file already exists";
  if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $name)) return "$label: could not save file";
  // one file per label: remove the old one
  $old = $pdo->prepare('SELECT file_path FROM student_files WHERE student_id=? AND label=?');
  $old->execute([$sid, $label]);
  foreach ($old as $o) @unlink(UPLOAD_DIR . $o['file_path']);
  $pdo->prepare('DELETE FROM student_files WHERE student_id=? AND label=?')->execute([$sid, $label]);
  $pdo->prepare('INSERT INTO student_files(student_id,label,file_path,file_type) VALUES(?,?,?,?)')
      ->execute([$sid, $label, $name, $mime]);
  return '';
}
function saveAllUploads(PDO $pdo, int $sid): array {
  $errs = [];
  foreach (['profile'=>'profile','id_proof'=>'id_proof','certificate'=>'certificate'] as $field=>$label) {
    $r = saveUpload($pdo, $sid, $field, $label); if ($r) $errs[] = $r;
  }
  return $errs;
}
