<?php require 'config.php';
$rows = $pdo->query('SELECT * FROM students ORDER BY id DESC')->fetchAll(); ?>
<!DOCTYPE html><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:Arial;margin:20px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:8px}</style>
<h2>Students</h2><a href="add.php">+ Add Student</a>
<table><tr><th>Roll No</th><th>Name</th><th>Course</th><th>Actions</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= e($r['roll_no']) ?></td><td><?= e($r['name']) ?></td><td><?= e($r['course']) ?></td>
<td><a href="view.php?id=<?= $r['id'] ?>">View</a> | <a href="edit.php?id=<?= $r['id'] ?>">Edit</a> |
<form method="post" action="delete.php" style="display:inline" onsubmit="return confirm('Delete this student?')">
<input type="hidden" name="id" value="<?= $r['id'] ?>"><button>Delete</button></form></td></tr>
<?php endforeach; ?></table>
