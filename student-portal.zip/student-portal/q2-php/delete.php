<?php require 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)$_POST['id'];
  $f = $pdo->prepare('SELECT file_path FROM student_files WHERE student_id=?'); $f->execute([$id]);
  foreach ($f as $row) @unlink(UPLOAD_DIR . $row['file_path']);       // remove files from disk
  $pdo->prepare('DELETE FROM students WHERE id=?')->execute([$id]);   // metadata removed by ON DELETE CASCADE
}
header('Location: index.php');
