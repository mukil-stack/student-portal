<?php require 'config.php';
$errors = []; $s = $_POST;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    $pdo->prepare('INSERT INTO students(name,roll_no,email,course) VALUES(?,?,?,?)')
        ->execute([trim($_POST['name']), trim($_POST['roll_no']), trim($_POST['email']), trim($_POST['course'] ?? '')]);
    $sid = (int)$pdo->lastInsertId();
    $errors = saveAllUploads($pdo, $sid);
    if (!$errors) { header('Location: view.php?id=' . $sid); exit; }
  } catch (PDOException $ex) {
    $errors[] = $ex->getCode() == 23000 ? 'Roll number already exists' : 'Database error';
  }
}
echo '<h2>Add Student</h2>'; include '_form.php';
